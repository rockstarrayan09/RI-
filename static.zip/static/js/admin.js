(function () {
    "use strict";

    function previewImage(input) {
        var previewContainer = input.closest("form, .admin-panel").querySelector(".image-preview");
        if (!previewContainer) {
            previewContainer = document.createElement("div");
            previewContainer.className = "image-preview";
            input.insertAdjacentElement("afterend", previewContainer);
        }

        previewContainer.innerHTML = "";

        if (!input.files || !input.files[0]) return;

        var file = input.files[0];
        var allowed = ["image/jpeg", "image/png", "image/webp"];
        if (allowed.indexOf(file.type) === -1) {
            previewContainer.innerHTML = '<p class="field-error">Please choose JPG, PNG, or WEBP.</p>';
            input.value = "";
            return;
        }

        var img = document.createElement("img");
        img.alt = "Preview";
        img.src = URL.createObjectURL(file);
        previewContainer.appendChild(img);
    }

    document.querySelectorAll('input[type="file"]').forEach(function (input) {
        input.addEventListener("change", function () {
            previewImage(input);
        });
    });

    document.querySelectorAll(".delete-form").forEach(function (deleteForm) {
        deleteForm.addEventListener("submit", function (event) {
            if (!confirm("Delete this service?")) {
                event.preventDefault();
            }
        });
    });

    var showMoreBtn = document.getElementById("show-more-services");
    if (showMoreBtn) {
        var moreLabel = showMoreBtn.textContent;
        showMoreBtn.addEventListener("click", function () {
            var list = document.getElementById("admin-service-list");
            var isShowingAll = list.classList.toggle("show-all");
            showMoreBtn.textContent = isShowingAll ? "Show Less Services" : moreLabel;
        });
    }
})();
