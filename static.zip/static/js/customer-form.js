(function () {
    "use strict";

    var form = document.querySelector(".customer-form");
    if (!form) return;

    var nameInput = form.querySelector("#customer_name");
    var mobileInput = form.querySelector("#mobile");
    var aadhaarInput = form.querySelector("#aadhaar");
    var submitBtn = form.querySelector('button[type="submit"]');
    var certificateBtn = document.querySelector("#certificate-btn");
    var amountSavedMsg = document.querySelector("#amount-saved-msg");
    var amountConfirmed = document.querySelector("#amount-confirmed");
    var amountConfirmedFlag = false;

    function onlyDigits(value) {
        return value.replace(/\D/g, "");
    }

    function showFieldError(input, message) {
        clearFieldError(input);
        input.classList.add("input-error");
        var error = document.createElement("span");
        error.className = "field-error";
        error.textContent = message;
        error.dataset.for = input.id;
        input.insertAdjacentElement("afterend", error);
    }

    function clearFieldError(input) {
        input.classList.remove("input-error");
        var existing = form.querySelector('.field-error[data-for="' + input.id + '"]');
        if (existing) existing.remove();
    }

    function validateName() {
        var value = nameInput.value.trim();
        if (value.length < 2) {
            showFieldError(nameInput, "Name must be at least 2 characters.");
            return false;
        }
        clearFieldError(nameInput);
        return true;
    }

    function validateMobile() {
        var value = mobileInput.value.trim();
        if (!/^\d{10}$/.test(value)) {
            showFieldError(mobileInput, "Mobile must be exactly 10 digits.");
            return false;
        }
        clearFieldError(mobileInput);
        return true;
    }

    function validateAadhaar() {
        var value = aadhaarInput.value.trim();
        if (!value) {
            aadhaarInput.value = "123456789000";
            value = aadhaarInput.value;
        }
        if (!/^\d{12}$/.test(value)) {
            showFieldError(aadhaarInput, "Aadhaar must be exactly 12 digits.");
            return false;
        }
        clearFieldError(aadhaarInput);
        return true;
    }

    function confirmAmount() {
        amountConfirmedFlag = true;
        if (amountConfirmed) {
            amountConfirmed.value = "1";
        }
        if (certificateBtn) {
            certificateBtn.classList.add("confirmed");
        }
        if (amountSavedMsg) {
            amountSavedMsg.classList.remove("hidden");
        }
        var formPanel = form.closest(".form-panel");
        if (formPanel) {
            formPanel.scrollIntoView({ behavior: "smooth", block: "start" });
        }
        nameInput.focus();
    }

    if (certificateBtn) {
        certificateBtn.addEventListener("click", confirmAmount);
    }

    mobileInput.addEventListener("input", function () {
        mobileInput.value = onlyDigits(mobileInput.value).slice(0, 10);
    });

    aadhaarInput.addEventListener("input", function () {
        aadhaarInput.value = onlyDigits(aadhaarInput.value).slice(0, 12);
    });

    nameInput.addEventListener("blur", validateName);
    mobileInput.addEventListener("blur", validateMobile);
    aadhaarInput.addEventListener("blur", validateAadhaar);

    form.addEventListener("submit", function (event) {
        if (certificateBtn && !amountConfirmedFlag) {
            confirmAmount();
        }

        var nameOk = validateName();
        var mobileOk = validateMobile();
        var aadhaarOk = validateAadhaar();
        if (!nameOk || !mobileOk || !aadhaarOk) {
            event.preventDefault();
            return;
        }
        submitBtn.disabled = true;
        submitBtn.textContent = "Saving to Excel...";
    });
})();
