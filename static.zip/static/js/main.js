(function () {
    "use strict";

    function initMobileNav() {
        var nav = document.querySelector(".site-nav");
        var toggle = document.querySelector(".nav-toggle");
        if (!nav || !toggle) return;

        toggle.addEventListener("click", function () {
            var isOpen = nav.classList.toggle("open");
            toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        });
    }

    function initFlashMessages() {
        var messages = document.querySelectorAll(".flash-messages .flash");
        messages.forEach(function (flash) {
            setTimeout(function () {
                flash.style.opacity = "0";
                flash.style.transform = "translateY(-8px)";
                setTimeout(function () {
                    flash.remove();
                }, 300);
            }, 5000);
        });
    }

    function initServiceCards() {
        var cards = document.querySelectorAll(".service-card");
        cards.forEach(function (card) {
            card.addEventListener("keydown", function (event) {
                if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    card.click();
                }
            });
        });
    }

    document.addEventListener("DOMContentLoaded", function () {
        initMobileNav();
        initFlashMessages();
        initServiceCards();
    });
})();
